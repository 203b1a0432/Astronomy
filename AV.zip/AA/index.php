<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>astronomy viewer</title>
    <link rel="shortcut icon" href="asco.png">
    <link rel="icon" href="asco.png" type="image/x-icon">
    <style>
        body {
            margin: 0;
            padding: 0;
            overflow: hidden;
            background: #000;
            color: #fff;
            display: flex;
            flex-direction: column; /* Change to column layout */
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        #video-background {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        #content {
            position: relative;
            z-index: 1;
            text-align: center;
            display: flex;
            flex-direction: column;
            align-items: center;
        }

        #explore-button {
            background: none;
            border: none;
            padding: 20px 40px;
            cursor: pointer;
            display: flex;
            align-items: center;
            font-size: 30px; /* Increase the font size */
            color: #fff; /* Set text color to white */
            transition: box-shadow 0.3s, transform 0.2s; /* Add transitions for hover effect */
            box-shadow: 0 0 20px rgba(255, 255, 255, 0); /* Start with no glow */
        }

        #explore-button:hover {
            box-shadow: 0 0 20px rgba(255, 255, 255, 1); /* Glow in white on hover */
        }

        #explore-button:active {
            transform: scale(0.95); /* Slight scale down when clicked */
        }

        #arrow {
            font-size: 24px;
            margin-left: 10px;
        }

        /* Center the text within the container */
        #content h1, #content p {
            margin: 0; /* Remove default margin */
            font-size: 36px; /* Increase the font size for the text */
        }

        /* Round favicon */
        link[rel*='icon'] {
            border-radius: 50%;
        }

        /* Style for the small round icon */
        .small-icon {
            width: 100px; /* Increase the size of the icon */
            height: 100px;
            margin: 10px 0; /* Margin to separate it from the text */
            border-radius: 50%;
        }
    </style>
</head>
<body>
    <video autoplay loop muted id="video-background">
        <source src="gg.mp4" type="video/mp4">
        Your browser does not support the video tag.
    </video>

    <div id="content">
        <h1>Welcome To Astronomy Viewer</h1>
        <h1>Your Window to the Universe.</h1>
        <button id="explore-button">
            Explore
            <span id="arrow">&#8594;</span>
        </button>
    </div>

    <script>
        document.getElementById('explore-button').addEventListener('click', function() {
            // Redirect to the explore page
            window.location.href = 'explore.php'; // Change 'explore.php' to the name of the PHP page you want to open
        });

        document.getElementById('arrow-button').addEventListener('click', function() {
            // Scroll to a specific section or perform an action when the arrow button is clicked
        });
    </script>
</body>
</html>
